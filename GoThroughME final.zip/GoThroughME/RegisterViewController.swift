//
//  RegisterViewController.swift
//  GoThroughME
//
//  Created by 978570 on 25/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift


class RegisterViewController: UIViewController {
    
    @IBOutlet weak var empID: UITextField!
    @IBOutlet weak var emailID: UITextField!
    @IBOutlet weak var phoneNumber: UITextField!
    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var userType: UITextField!
    @IBOutlet weak var category: UITextField!
    @IBOutlet weak var register: UIButton!
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    func addUser()
    {
        let user = UserClass()

        if (empID.text != nil){
            user.empID = empID.text!
        }
        if (emailID.text != nil){
            user.emailID = emailID.text!
        }
        if (phoneNumber.text != nil){
            user.phoneNumber = phoneNumber.text!
        }
        if (password.text != nil){
            user.password = password.text!
        }
        if (userType.text != nil){
            user.userType = userType.text!
        }
        if (category.text != nil){
            user.category = category.text!
        }
        let realm = try! Realm()
        
        try! realm.write {
            realm.add(user)
            print("added ")
        }
        UserdataModel.sharedUserModel.userData = user
        let homeViewController = self.storyboard!.instantiateViewController(withIdentifier: "homeNavID") as! UINavigationController
        self.present(homeViewController, animated:true, completion: nil)
    }
    @IBAction func RegisterAction(_ sender: Any) {
        queryPatient()
    }
    func queryPatient()  {
        let realm = try! Realm()
        let folderPath = realm.configuration.fileURL!.deletingLastPathComponent().path
        print("folder path is \(folderPath)")
        let allUsers = realm.objects(UserClass.self)
        //        let  = allPatients.filter("age = 13")
        for user in allUsers
        {
            if user.empID == empID.text 
            {
              Alert.showAlert(title: "GoThrough", message: "User Already Added", viewController: self)
                return
            }
            else{
                addUser()
            }
        }
    }
}

