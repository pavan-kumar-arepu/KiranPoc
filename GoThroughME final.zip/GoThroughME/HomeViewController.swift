//
//  HomeViewController.swift
//  GoThroughME
//
//  Created by 978570 on 25/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation
import UIKit

class HomeViewController: UIViewController, ENSideMenuDelegate ,UITableViewDelegate,UITableViewDataSource{
    
    // pdf files are there in document directory and here i am hardcoded

    var tableData:[String:String] = ["Objective - c":"https://www.cyberprogrammers.net/2015/06/objective-c-ebooks-for-beginner-and-for.html", "ECE":"https://www.cyberprogrammers.net/2015/06/objective-c-ebooks-for-beginner-and-for.html", "CSE":"https://www.cyberprogrammers.net/2015/06/objective-c-ebooks-for-beginner-and-for.html"]
    
    @IBOutlet weak var userCatLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        self.sideMenuController()?.sideMenu?.delegate = self
        homeTableView.delegate = self
        homeTableView.dataSource = self
        userCatLabel.text = UserdataModel.sharedUserModel.userData?.userType
    }
    
    @IBOutlet weak var sideMenu: UIBarButtonItem!
    
    @IBOutlet weak var homeTableView: UITableView!
    @IBAction func sideMenuAction(_ sender: Any) {
        toggleSideMenuView()

    }
    // MARK: - ENSideMenu Delegate
    func sideMenuWillOpen() {
        print("sideMenuWillOpen")
    }
    
    func sideMenuWillClose() {
        print("sideMenuWillClose")
    }
    
    func sideMenuShouldOpenSideMenu() -> Bool {
        print("sideMenuShouldOpenSideMenu")
        return true
    }
    
    func sideMenuDidClose() {
        print("sideMenuDidClose")
    }
    
    func sideMenuDidOpen() {
        print("sideMenuDidOpen")
    }
    // TableView delegate and datasource methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.tableData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cellReuseIdentifier")! //1.
        cell.textLabel?.text = Array(tableData.keys)[indexPath.row] //3.
        return cell
    }
        
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
    }

        
}
