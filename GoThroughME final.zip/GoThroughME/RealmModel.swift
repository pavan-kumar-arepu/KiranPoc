//
//  RealmModel.swift
//  GoThroughME
//
//  Created by 978570 on 24/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation
import RealmSwift
import UIKit

class UserClass : Object
{
    @objc dynamic var empID = ""
    @objc dynamic var emailID = ""
    @objc dynamic var phoneNumber = ""
    @objc dynamic var password = ""
    @objc dynamic var userType = ""
    @objc dynamic var category = ""
}
class BooksClass : Object
{
    @objc dynamic var bookName = ""
    @objc dynamic var bookImage = ""
    @objc dynamic var bookAvailabilty = ""
    @objc dynamic var bookCat = ""
}
class CurrentUserClass : Object
{
    @objc dynamic var currentEmpID = ""
    @objc dynamic var currentEmailID = ""
    @objc dynamic var currentPhoneNumber = ""
    @objc dynamic var currentPassword = ""
    @objc dynamic var currentUserType = ""
    @objc dynamic var currentCategory = ""
}
class Alert: UIAlertController {
    
   static func showAlert(title:String, message:String, viewController:UIViewController)
    {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "ok", style: .cancel, handler: nil))
        viewController.present(alert, animated: true, completion: nil)
    }
   
}
