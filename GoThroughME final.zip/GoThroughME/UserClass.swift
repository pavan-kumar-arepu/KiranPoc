//
//  UserClass.swift
//  GoThroughME
//
//  Created by 978570 on 25/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation

final class UserdataModel {
    
   static let sharedUserModel = UserdataModel()
    
    var userData:UserClass?
    
    private init() {
        
    }
}
