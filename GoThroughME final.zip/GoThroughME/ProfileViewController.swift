//
//  ProfileViewController.swift
//  GoThroughME
//
//  Created by 978570 on 25/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

class ProfileViewController :  UIViewController {
    override func viewDidLoad()
    {
        
        super.viewDidLoad()
    }
    
    @IBAction func sideMenu(_ sender: Any) {
        toggleSideMenuView()
    }
}
