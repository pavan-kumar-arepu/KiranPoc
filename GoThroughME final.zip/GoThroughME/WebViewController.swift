//
//  WebViewController.swift
//  GoThroughME
//
//  Created by 978570 on 25/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation

import Foundation
import UIKit

class WebViewController: UIViewController{

    @IBOutlet weak var backAction: UIBarButtonItem!
    
    @IBAction func backButtonAction(_ sender: Any) {
        _ = navigationController?.popViewController(animated: true)
    }
}
