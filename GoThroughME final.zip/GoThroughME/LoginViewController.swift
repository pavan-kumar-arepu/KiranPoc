//
//  LoginViewController.swift
//  GoThroughME
//
//  Created by 978570 on 25/05/18.
//  Copyright © 2018 KIran. All rights reserved.
//

import Foundation
import UIKit
import RealmSwift

class LoginViewController :  UIViewController {
    
    @IBOutlet weak var loginID : UITextField!
    @IBOutlet weak var password : UITextField!
    
    
    @IBAction func LoginAction(_ sender: Any) {
        if loginID.text != nil || password.text != nil {
        UserQuery()
        }
    }
    
    func UserQuery()  {
        let realm = try! Realm()
        
        let folderPath = realm.configuration.fileURL!.deletingLastPathComponent().path
        print("folder path is \(folderPath)")
        let allUsers = realm.objects(UserClass.self)
        for user in allUsers{
            if user.empID == loginID.text{
            print("\(user.empID) is \(user.password)")
                if user.password == password.text
                {
                   UserdataModel.sharedUserModel.userData = user
                    
                    let homeViewController = self.storyboard!.instantiateViewController(withIdentifier: "homeNavID") as! UINavigationController
                    self.present(homeViewController, animated:true, completion: nil)
                }
                else{
                    Alert.showAlert(title: "GoThroughME", message: "invalid password", viewController: self)
                    return
                }
            }
            else{
                Alert.showAlert(title: "GoThroughME", message: "invalid password and empid", viewController: self)
                return
            }
        }
    }
}
